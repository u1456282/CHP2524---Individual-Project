<!DOCTYPE html>
<html>
  <head>
  
    
   <label id="p2">Tap on the map below and tell us where the problem is</label>
   <br>
    <font color="red">
   <label id="p3">Coordinates not yet selected</label>
   </font>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <style>
       #map {
        height: 300px;
        width: 100%;
       }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <script>
var map;


function initialize() {
var myLatlng = new google.maps.LatLng(53.643123,-1.778133);

var myOptions = {
 zoom: 16,
 center: myLatlng,
 mapTypeId: google.maps.MapTypeId.ROADMAP
}
map = new google.maps.Map(document.getElementById("map"), myOptions);

var marker = new google.maps.Marker({
 draggable: true,
 position: myLatlng,
 map: map,
 title: "Your location"
});

google.maps.event.addListener(map, 'click', function(event) {
 document.getElementById("p3").style.color = "green";
 document.getElementById("p2").innerHTML = "Location received";
 document.getElementById('job_lon').value=event.latLng.lng();
 document.getElementById('job_lat').value=event.latLng.lat();
 var Gotlat = event.latLng.lat(); 
 var Gotlng = event.latLng.lng();
 var Gotlng9 = Gotlng.toString().substring(0,10);
 var Gotlat9 = Gotlat.toString().substring(0,9);
 var ShowToUser = "(" + Gotlat9 + ", " + Gotlng9 + ")";
 document.getElementById("p3").innerHTML = (ShowToUser);



});
map.addListener('click', function(e) {
    placeMarker(e.latLng, map);
});

function placeMarker(position, map) {

    var marker = new google.maps.Marker({
        position: position,
        map: map
    });

}

}
  

//google.maps.event.addDomListener(window, 'load', initialize);
initialize();
    </script>

  </body>
</html>