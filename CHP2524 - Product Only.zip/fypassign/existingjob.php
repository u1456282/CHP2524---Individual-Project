<?php
include ("header.php");
?>
   <body>
    
   <form action="existingjob.php" method="get">
   <form>
            <div class="Details1">
            <fieldset>
            <legend align="center">Enter your job ID to view updated</legend>
            <label for="search">Job ID:</label>
            <input placeholder="Enter Job ID" type="text" name="search" id="search">
            <br>
            <input type="submit" value="Search">
	    </fieldset>
            </div>
	   

   </form>

<?php
include("config/config.inc.php");

if(!isset($_GET['search']))
{
	echo "Your search will appear below";
	
	exit;
}
$counter = 0;
$search_term = $_GET['search'];

$stmt = $conn->prepare("SELECT * FROM job
		       WHERE job_id LIKE :search_term");
$stmt->bindValue(':search_term',$search_term);
$stmt->execute();
 
 if ($search_term == "")
 {
	echo "Enter a Job ID";
 }

 else
 {	
	
	
	
	echo "<form>";
	echo "<fieldset>";
	echo "<legend  align='center'>Jobs that match your search:</legend>";
	
while ($job = $stmt->fetch(PDO::FETCH_OBJ))
{
	
	
        echo "<li>"."<a href='details.php?job_id=".$job->job_id."'>";
	echo "<b>".$job->job_id." "."</b>"."</li>";
	echo "</a>";
	$counter++;
	
}

if($counter == 0){
 echo "Job ID not recognised.";
}
	echo "</fieldset>";
	echo "</form>";


}
$conn=NULL;
?>

</html>


