<?php
session_start();
if(!isset($_SESSION["user"]))
{
	//user tried to access the page without logging in
	header( "Location: login.php" );
};
?>
<?php

include("config/config.inc.php");
include("helpers/db_fncs.php");
include("models/job.php");
include("models/service.php");
include("models/job-model.php");
include("models/service-model.php");
include("views/view_fncs.php");
include ("header.php");

$conn=getConn();
$allJobs=getAllJobs($conn);
$conn=NULL;
include("views/all-jobs-view.php")
?>
