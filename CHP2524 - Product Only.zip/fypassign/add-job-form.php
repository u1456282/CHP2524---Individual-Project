
<?php
include("config/config.inc.php");
include("helpers/db_fncs.php");
include("helpers/validation_fncs.php");
include("models/job.php");
include("models/service.php");
include("models/job-model.php");
include("models/service-model.php");
include("views/view_fncs.php");
include ("header.php");

$conn=getConn();
$services=getAllServices($conn);
$conn=NULL;


include("views/add-job-form-view.php");

?>
