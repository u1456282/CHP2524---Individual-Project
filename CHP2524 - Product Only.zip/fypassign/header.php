<!DOCTYPE HTML>
<html>
   <head>
		<!--<meta http-equiv="content-type" content="text/html;charset=utf-8" />-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1.0">
	
	<link type="text/css" media='(max-device-width: 91800px)' rel="stylesheet" href="mobilestyle.css" />
 <link type="text/css" media='(min-device-width: 91800px)' rel='stylesheet' href="style.css" />
 <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato" />
 
	
<!--   <link rel="stylesheet" type="text/css" href="style.css">-->
<!--<div class="spinner"><img src="Images/kirkleeslogo.png"></div> -->
</div>
    <div class="menudimmer"></div>
    
    <header>
<div class="container">
 <!--<img class="movelogo" src="Images/kirkleeslogo.png" width="30" height="30" alt="Logo">-->
  <h1 class="Logo">KIRKLEES<span> COUNCIL</span><div class="spinner"><img src="Images/kirkleeslogo.png"></div> </h1>
  
  <nav class="TopNav">
      <ul>
       
              <?php
if ( $_SESSION["user"]=="Matthew") {
 echo	 '<li><a href="all-jobs.php"><i class="TopNav-Icon"></i>View/Edit Jobs</a></li>';
 echo	 '<li><a href="all-jobs-delete.php"><i class="TopNav-Icon"></i>Delete Jobs</a></li>';
 echo	 '<li><a href="logout.php"><i class="TopNav-Icon"></i>Logout</a></li>';
}
else {
echo	 '<li><a href="add-job-form.php"><i class="TopNav-Icon"></i>Add Job</a></li>';
 echo	 '<li><a href="existingjob.php"><i class="TopNav-Icon"></i>Track Progress</a></li>';
 echo	 '<li><a href="login.php"><i class="TopNav-Icon"></i>Login</a></li>';
 //echo   '<a class="NavButton" href="login.php"><img class="movelogo" src="Images/kirkleeslogo.png" width="30" height="30" alt="Logo"></a>';

}

?>
      </ul> 
  </nav>
  
  
       <?php
//if ( $_SESSION["user"]=="Matthew") {
// echo  	'<header>';
// echo	 '<a class="NavButton" href="all-jobs.php">View/Edit Jobs</a>';
//	 echo'<a class="NavButton" href="all-jobs-delete.php">Delete Jobs</a>';
//   echo '<a class="NavButton" href="logout.php">Logout</a>';
//	echo '</header>';
//}
//else {
//     echo  	'<header>';
// echo   '<a class="NavButton" href="login.php"><img class="movelogo" src="Images/kirkleeslogo.png" width="30" height="30" alt="Logo"></a>';
//  echo'<a class="NavButton" href="add-job-form.php">Add Job</a>';
//  echo  '<a class="NavButton" href="existingjob.php">Track Progress</a>';
//	echo '</header>';
//}

?>
  
  
  
  <div class="menu-toggle">
    <div class="hamburger"></div>
  </div>
  
</div>

</header>
	<div class="divsection">
	<!--<p class="HeaderLines"><span>Kirklees Council</span></p>-->
   <br>

	<section>


</head>
   <body>
      
      <div class="mbody">
         	<div class="header">

</div>
		</div>
		<footer>

<?php

if(!isset($_SESSION["user"])){
	//echo "<p>USER IS CURRENTLY LOGGED OUT AS DOLLAR_SESSION['user'] === '' <b>".$_SESSION["user"]."</b></p>";
}else{
	echo "<p>Logged in as <b>".$_SESSION["user"]."</b></p>";
}
?>
</footer>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>-->

  <script src="menu.js"></script>
<!--<div class="nav-bar"	-->