<!DOCTYPE html>
<html lang="en">
<body>
    <form method="post" enctype="multipart/form-data">
        Select image to upload:
        <input type="file" name="job_image"/>
        <input type="submit" name="submit" value="Upload"/>
    </>
</body>
</html>

<?php
if(isset($_POST["submit"])){
    $check = getimagesize($_FILES["job_image"]["tmp_name"]);
    if($check !== false){
        $job_image = $_FILES['job_image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($job_image));

        /*
         * Insert image data into database
         */
        
        //DB details
        $dbHost     = 'localhost';
        $dbUsername = 'u1456282';
        $dbPassword = '30oct95';
        $dbName     = 'u1456282';
        
        //Create connection and select DB
        $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
        
        //Insert image content into database
        $insert = $db->query("INSERT into images (job_image) VALUES ('$imgContent')");
        
        
        
        
        
        
        
        if($insert){
            echo "<br> File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
    }else{
        echo "Please select an image file to upload.";
    }
}
?>

