<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1.0">

<body>

<!--<form action="add-job.php" method="POST" enctype="multipart/form-data" id=regForm>-->
 <!-- multistep form -->
 
<!-- <div class="DetailsNew">-->

	<!-- progressbar -->
 <div class="progressbackground">
	<ul id="progressbar">
		<li class="active"></li>
		<li></li>
		<li></li>
  <li></li>
  <li></li>
	</ul>
 </div>


 <form form action="add-job.php" method="POST" enctype="multipart/form-data" id="msform">
	<!-- fieldsets -->
	<fieldset>

   <label for="title">Request a service</label> <br>
<input placeholder="Enter your name" type="text" name="resident_name" id="resident_name" required>
<br>
<input placeholder="Enter your email" type="text" name="resident_email" id="resident_email" required>

		<input type="button" name="next" class="next action-button" value="Next" id="nextone" disabled/>
	</fieldset>
	<fieldset>
	<select name="service[]" id="service[]" value="'.$service->service_id.'">;
        <option class="DDC" selected="selected"><p style="color:rgba(255, 255, 255, 0.7)">Choose a category</p></option>
       
	    <?php
        foreach($services as $service){
        ?>
        <option class="DDC" value="<?php echo ($service->service_id); ?>"><?php echo $service->service_name; ?></option>
        <?php
        }
        ?>
    </select>
<br>
<input placeholder="Optional notes" type="text" name="job_notes" id="job_notes" >

		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" id="nexttwo" disabled />
	</fieldset>
	<fieldset>
  
 
  <div class="fuupload-btn-wrapper">
   <button class="fubtn">Upload a Photo</button>
  <input type="file" name="job_image" id="job_image" required/>
</div>
        
        <br>
        
        
        
        
        
		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" id="nextthree" disabled/>
	</fieldset>
 
  <fieldset>
<?php
include ("getmap.php");
?>

		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" id="nextfour" disabled/>
	</fieldset>
  <fieldset>
   <input type="button" name="previous" class="previous action-button" value="Previous" id="prevfour"/>
<input type="submit" name="submitBtn" value="Add Job" class="AddJobButton">
  </fieldset>

  </div>
  <!--BELOW CREATES AND HIDES TEXT FIELDS WHICH CONTAIN THE LON AND LAT VALUES WHICH GET SENT TO THE DATABASE-->
<label id="lonlathide" for="title">Lat:</label>
<input type="text" name="job_lat" id="job_lat" required>

<label id="lonlathide2" for="title">Lon:</label>
<input type="text" name="job_lon" id="job_lon" required>

		<script type="text/javascript">
        document.getElementById('job_lat').style.display = 'none';
								document.getElementById('job_lon').style.display = 'none';
								document.getElementById('lonlathide').style.display = 'none';
								document.getElementById('lonlathide2').style.display = 'none';
</script>
      </form>

</div>
  
  
  
  
  
  
<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
<!-- jQuery easing plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>

<script>


 $(':text').keyup(function() {
    if($('#resident_name').val() != "" && $('#resident_email').val() != "") {
       $('#nextone').removeAttr('disabled');
    } else {
       $('#nextone').attr('disabled', true);
    }
});
 
 $(':text').keyup(function() {
    if($('#job_notes').val() != "" ) {
       $('#nexttwo').removeAttr('disabled');
    } else {
       $('#nexttwo').attr('disabled', true);
    }
});
 $('#nextthree').removeAttr('disabled');
 $('#nextfour').removeAttr('disabled');
// $("#job_image").hover(function() { // bCheck is a input type button
//    var fileName = $("#job_image").val();
//    if(fileName) { // returns true if the string is not empty
//        $('#nextthree').removeAttr('disabled');
//    } else { // no file was selected
//        $('#nextthree').attr('disabled', true);
//          }
//});
//  $("#job_image").mousemove(function() { // bCheck is a input type button
//    var fileName = $("#job_image").val();
//    if(fileName) { // returns true if the string is not empty
//        $('#nextthree').removeAttr('disabled');
//    } else { // no file was selected
//        $('#nextthree').attr('disabled', true);
//          }
//});
//  
//  
//   $('#msform').mousemove(function() {
//    if($('#job_lat').val() != "") {
//       $('#nextfour').removeAttr('disabled');
//    } else {
//       $('#nextfour').attr('disabled', true);
//    }
//});
//  
   
 $("#reset").click(function(){
  document.location.reload(true);
});
$(function() {
 
//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches
 
$(".next").click(function(){
	if(animating) return false;
	animating = true;
 
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
 
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
 
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 1;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'transform': 'scale('+scale+')'});
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});
 
$(".previous").click(function(){
	if(animating) return false;
	animating = true;
 
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
 
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
 
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

 
});

</script>

</body>
</html>
