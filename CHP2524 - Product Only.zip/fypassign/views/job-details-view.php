<html>

<style>
img.hidden {
    display: none;
}
</style>


  </body>
<script>
 
 $( document ).ready(function() {
        document.getElementById('job_img').style.display='none';
    });
 
 
 function job_img(x)
 {
  if (x==0)
  document.getElementById('job_img').style.display='inline';
  else
  document.getElementById('job_img').style.display='none';
  return;
 }
</script>



<?php
showHeader("Job Details");
showNavigation();

 echo "<div class=divsection>";
		
	echo "<section>";
echo "<div class=FadeIn1>";
	echo "<form>";
	echo "<fieldset>";
	echo "<legend align='center'>Job Details</legend>";
	
 echo "<b>"."Requested Service: "."</b>";
foreach($job->services as $service)
{
	echo $service->service_name.". ";
}
echo "<br>";
 echo "<b>"."Reported On: "."</b>".$job->job_datetime;
echo "<br>";      
echo "<b>"."Additional Notes: "."</b>".$job->job_notes;
echo "<br>";	
 
echo "<b>"."Resident Name: "."</b>".$job->resident_name;




	echo "</fieldset>";
	echo "</form>";
 echo "</div>";
 
 
 $ShowImage = $job->job_image;
$ShowImage5 = substr($ShowImage, 5); // removes "/tmp/" from the string in the database
 
 echo "<div class=FadeIn1>";
 echo "<fieldset>";
	echo "<legend align='center'>Image</legend>";
 
 echo '<input type=button value= Show name=imgshow onclick=job_img(0) >';
 echo '<input type=button value= Hide name=imghide onclick=job_img(1) >';
 echo '<br>';

   echo '<img class="hidden" src="uploads/'.$ShowImage5.'" alt="Attached Photo" height="356" width="200" id="job_img" align="middle">';


 //echo '<img src="uploads/'.$ShowImage5.'" alt="Attached Photo" height="0" width="0">';
 
 //list($imagewidth, $imageheight, $imagetype, $imageattr) = getimagesize("uploads/".$ShowImage5);
 //echo "<br>";
 //
 // echo "Image width: " . $imagewidth;
 // echo "<br>";
 // echo "Image height: " . $imageheight;
 // echo "<br>";
 // echo "Attribute: " . $imageattr;
  
  $imageUrl = ("uploads/".$ShowImage5);
  
	echo "</fieldset>";
	echo "</form>";
 echo "</div>";
 
 
  echo "<div class=FadeIn1>";
 echo "<fieldset>";
	echo "<legend align='center'>Location</legend>";
include ("viewmap.php");
	echo "</fieldset>";
	echo "</form>";
 echo "</div>";
 
 
 
 
 echo "<div class=FadeIn1>";
	echo "<fieldset>";
	echo "<legend align='center'>Job Progress</legend>";

 
 
 if ($job->job_progress == 1)
 {
echo '<img src="ProgressUpdate1.png" alt="ProgressUpdate1">';
echo '<br> We have received this job but have not yet scheduled a repair.';
 }
 if ($job->job_progress == 2) {
echo '<img src="ProgressUpdate2.png" alt="ProgressUpdate2">';
echo '<br> We expect this job to be complete within the next 2 weeks.';
 }
  if ($job->job_progress == 3) {
echo '<img src="ProgressUpdate3.png" alt="ProgressUpdate3">';
echo '<br> We expect this job to be complete within the next 2 days.';
 }
  if ($job->job_progress == 4) {
 echo '<img src="ProgressUpdate4.png" alt="ProgressUpdate4">';
 echo '<br> This job has been completed.';
 }
 
  echo "<br>";
 	echo "</fieldset>";
 echo "</div>";
 
echo "<div class=FadeIn1>";
	echo "<form>";
 
if ($job->job_yard == 1) 
echo "<fieldset class=FSAlert>";
else
echo "<fieldset class=FSNormal>";
 
 
	echo "<legend align='center'>Designated Yard</legend>";
 
 
 if ($job->job_yard == 1) echo "NONE ASSIGNED";
 if ($job->job_yard == 2) echo "Batley";
 if ($job->job_yard == 3) echo "Colne Valley";
 if ($job->job_yard == 4) echo "Denby Dale";
 if ($job->job_yard == 5) echo "Holme Valley";
 if ($job->job_yard == 6) echo "Huddersfield East";
 if ($job->job_yard == 7) echo "Huddersfield West";
 if ($job->job_yard == 8) echo "Kirkbutron";
 if ($job->job_yard == 9) echo "Mirfield";
 if ($job->job_yard == 10) echo "Spen Valley & Heckmondwike";
 
 echo "<br>";
 
 
 
 
 echo "</fieldset>";
	echo "</form>";
 echo "</div>";
 
  echo "<div class=FadeIn1>";
	echo "<fieldset>";
	echo "<legend align='center'>Update Data Console</legend>";
 
 include ("update.php");
 //echo "<a input href='all-jobs.php' name='Return To Jobs'>Return To Jobs</a>";
 	echo "</fieldset>";
	echo "</form>";
 echo "</div>";
 
 

 
 
 
 
        
	echo "</section>";

	
showFooter();

?>
</body>

</html>