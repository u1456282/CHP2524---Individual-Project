
<?php
showHeader("There was a problem");
showNavigation();

echo "<p>There seems to be a problem. Please choose one of the options above.</p>";

showFooter();

?>
