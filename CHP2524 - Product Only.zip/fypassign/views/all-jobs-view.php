<?php

showHeader("Show All Jobs");
showNavigation();

 echo "<div class=divsection>";
		
	echo "<section>";
echo "<div class=FadeIn1>";
	echo "<form>";
	//echo "<fieldset>";
	//echo "<legend align='center'>All Jobs</legend>";

foreach($allJobs as $job){
 
 
 if ($job->job_yard == 1) 
echo "<fieldset class=FSAlert>";
else
echo "<fieldset class=FSNormal>";
 
 
 
 
	echo "<a href='job-details.php?job_id=".$job->job_id."'>";
	echo "ID: "."<b>".$job->job_id."</b>"." - (".$job->resident_name.")";
	echo "</a>";
 echo "</fieldset>";
	echo "<br>";
}
//	echo "</fieldset>";
	echo "</form>";
        echo "</div>";
	echo "</section>";
	
	
showFooter();