<?php
showHeader("Add a new job");
showNavigation();
?>


<head>
	<title>Index</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<link href="style.css" rel="stylesheet" type="text/css">
		<body>
			
            <div class="Details1">
            <fieldset>
            <legend>Enter a Search Term</legend>
            <label for="search">Job Name:</label>
            <input type="text" name="search" id="search">
            <input type="submit" value="Search">
	    </fieldset>
            </div>
	   

   </form>
	
	
<?php

if(!isset($_GET['search']))
{
	echo "Your search results will be shown here";
	
	exit;
}

$counter = 0;

$search_term = $_GET['search'];

$stmt = $conn->prepare("SELECT * FROM job
		       WHERE resident_name LIKE :search_term");
$stmt->bindValue(':search_term','%'.$search_term.'%');
$stmt->execute();
 
 if ($search_term == "")
 {
	echo "Search cannot be left empty";
 }

 else
 {	
	
	
	
	echo "<form>";
	echo "<fieldset>";
	echo "<legend>Songs that match your search:</legend>";
	
while ($job = $stmt->fetch(PDO::FETCH_OBJ))
{
	
	
        echo "<li>"."<a href='job-details.php?job_id=".$job->job_id."'>";
	echo "<b>".$job->resident_name."</b>"."</li>";
	echo "</a>";
	$counter++;

	
}
	echo "</fieldset>";
	echo "</form>";

	
	echo "<form>";
	echo "<fieldset>";
	echo "<legend>Search info:</legend>";
	echo "You searched for: '".$search_term."' and found "."<b>".$counter."</b>"." results.";
	echo "</fieldset>";
	echo "</form>";
}
$conn=NULL;
?>

</html>


