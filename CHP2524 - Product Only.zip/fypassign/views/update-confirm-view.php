
<?php

       echo 'Job progress updated to '.$job_progress;
       echo '<br>';
       echo 'Refreshing current page';

showFooter();

?>
