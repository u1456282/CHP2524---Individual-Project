
<?php
showHeader("Successfully Added The Job");
showNavigation();
$service_name = $_SESSION['service_name'];

echo "Your reference number for this job is; "."<br>";
echo "<li>"."<a href='details.php?job_id=".$job->job_id."'>";
echo "<b>"."<font size=24>".$job->job_id."</b>"."</font>"."<br>";
echo "</a></li>";

echo "Submit this reference number in the 'Existing options' section to receive updates or click on your ID number<br>";
showFooter();

?>
