
<?php
showHeader("There was a problem");
showNavigation();

foreach($errorMsgs as $errorMsg)
{
	echo "<p>".$errorMsg."</p>";
}
 echo "<a input href='add-job-form.php' name='Return To Form'>Return To Form</a>";

showFooter();

?>
