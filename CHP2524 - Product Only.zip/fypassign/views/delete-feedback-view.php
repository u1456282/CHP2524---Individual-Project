<?php

showHeader("Delete Jobs");
showNavigation();

echo "<p>".$msg."</p>";
showFooter();
?>