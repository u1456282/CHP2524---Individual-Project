<?php

showHeader("Delete Jobs");
showNavigation();

echo "<form action='delete-jobs.php' method='POST'>";

 echo "<div class=divsection>";
		
	echo "<section>";
echo "<div class=FadeIn1>";
	echo "<form>";
	echo "<fieldset>";
	echo "<legend align='center'>Delete Jobs</legend>";




foreach($allJobs as $job)
{
	echo "<div class=DetailsDelete>";
	echo "<label>".$job->resident_name."</label>";
	echo "<input type='checkbox' value='".$job->job_id."' name='jobs[]'/>";
    echo "</div>";
}
echo "<input type='submit' name='deleteJobsBtn' value='Delete Jobs'>";
	echo "   ";
	echo "<input class='ResetButton' type='reset' name='Reset'>";
echo "</form>";

	echo "</fieldset>";
	echo "</form>";
        echo "</div>";
	echo "</section>";
	

showFooter();
?>