<?php

function showHeader($title="The Jobs Site")
{
	echo '<!DOCTYPE HTML>';
	echo '<html>';
	echo '<head>';
	echo '<title>'.$title.'</title>';
	echo '<meta http-equiv="content-type" content="text/html;charset=utf-8" />';
	echo '</head>';
	echo '<body>';
}
function showNavigation()
{
}

function showFooter()
{
	echo '</body>';
	echo '</html>';
}

?>