<?php
include ("header.php");
?>
<?php

session_start();

if($_POST['username']=="Matthew"&&$_POST['password']=="Password")
{
    $_SESSION['user']=$_POST['username'];
    header( "Location: welcome.php" );

    
}
else
{
    header( "Location: login.php" );

    
}

?>