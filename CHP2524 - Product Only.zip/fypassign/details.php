<?php
include ("header.php");
?>

<body>
<?php
include("config/config.inc.php");
  
    if(!isset($_GET['job_id']))
{
	echo "Enter ";
	exit;

}

$job_id = $_GET['job_id'];


$query = "SELECT * FROM job WHERE job_id=:job_id";
$query ="SELECT job_id, job_progress, job_datetime FROM job WHERE job.job_id=:job_id";


$stmt = $conn->prepare($query);
$stmt->bindValue(':job_id',$job_id);
$stmt->execute();


if ($job=$stmt->fetch(PDO::FETCH_OBJ))
{
        echo "<div class=FadeIn1>";
	echo "<form>";
	echo "<fieldset>";
	echo "<legend>Job Details</legend>";
	echo "<li>Job ID: "."<b>".$job->job_id."</b>"."</li>";
        echo "<li>Reported on: "."<b>".$job->job_datetime."</b>"."</li>";
	echo "</fieldset>";
	echo "</form>";
	echo "</div>";

	
	echo "<div class=FadeIn1>";
        echo "<form>";
	echo "<fieldset>";
	echo "<legend>Track progress</legend>";
 
 
 if ($job->job_progress == 1)
 {
echo '<img src="ProgressUpdate1.png" alt="ProgressUpdate1">';
echo '<br> We have received this job but have not yet scheduled a repair.';
 }
 if ($job->job_progress == 2) {
echo '<img src="ProgressUpdate2.png" alt="ProgressUpdate2">';
echo '<br> We expect this job to be complete within the next 2 weeks.';
 }
  if ($job->job_progress == 3) {
echo '<img src="ProgressUpdate3.png" alt="ProgressUpdate3">';
echo '<br> We expect this job to be complete within the next 2 days.';
 }
  if ($job->job_progress == 4) {
 echo '<img src="ProgressUpdate4.png" alt="ProgressUpdate4">';
 echo '<br> This job has been completed.';
 }
        
	echo "</fieldset>";
	echo "</form>";
	echo "</div>";
}
						
	
	echo "</fieldset>";
	echo "</form>";
	echo "</div>";
			



$conn=NULL;
?>


