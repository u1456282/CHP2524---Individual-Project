<!DOCTYPE html>
<html>
  <head>
    <style>
       #map {
        height: 400px;
        width: 100%;
       }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <script>
        
        
        //constructs new map object and adds properties to the map including the center and zoom level
      function initMap() {
        var uluru = {lat: 53.640915, lng: -1.777775};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: uluru
        });
        
        //PUTS A MARKER ON THE MAP
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDgilBcb5ASCbUzmOj4Tacigernpf2PXTQ&callback=initMap">
    </script>
  </body>
</html>