<?php
include("config/config.inc.php");
include("helpers/db_fncs.php");
include("views/view_fncs.php");
include ("header.php");
include("views/search-view.php");
?>
