<?php
session_start();
?>
<?php
include("config/config.inc.php");
include("helpers/db_fncs.php");
include("helpers/validation_fncs.php");
include("models/job.php");
include("models/service.php");
include("models/job-model.php");
include("models/service-model.php");
include("views/view_fncs.php");
include ("header.php");

//check if they've submitted the form
if(!isset($_POST["submitBtn"]))
{
	header("Location:add-job-form.php");
}
//get the form data
$resident_name=$_POST['resident_name'];
$resident_email=$_POST['resident_email'];
$job_notes=$_POST['job_notes'];
$job_progress=$_POST['job_progress'];
$job_datetime=$_POST['job_datetime'];
$job_lat=$_POST['job_lat'];
$job_lon=$_POST['job_lon'];
$serviceIds;
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["job_image"]["tmp_name"]);
$extension = $_FILES['job_image']['name'];
$imageFileType = strtolower(pathinfo($extension,PATHINFO_EXTENSION));

//$validate the form data
$validForm=true;
$errorMsgs=[];

if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
	
	$validForm=false;
	$errorMsgs[]="Only JPG & JPEG files are allowed.";
}

if(!complete($resident_name))
{
	$validForm=false;
	$errorMsgs[]="<p>You must enter your name</p>";
}

if(!isset($_POST['service']))
{
	$validForm=false;
	$errorMsgs[]="<p>You must describe the problem using the buttons and/or text box</p>";
}else{
	$serviceIds=$_POST['service'];
}

if(!$validForm)
{
	include("views/add-job-error-view.php");
	exit;
}

//Now try and insert the data
$conn=getConn();
$matchingServices=[];
foreach($serviceIds as $service_id)
{
	$matchingServices[]=getServiceById($conn,$service_id);
}
$job=new Job();
$job->resident_name=$resident_name;
$job->job_notes=$job_notes;
$job->job_progress=1;
$date = new DateTime;
$job->job_datetime=$date->format('Y-m-d H:i:s');
$job->job_yard=1;
$job->job_lat=$job_lat;
$job->job_lon=$job_lon;
$job->resident_email=$resident_email;

//new
$job_image = $_FILES['job_image']['tmp_name'];

move_uploaded_file($_FILES["job_image"]["tmp_name"], $target_file);

$job->job_image=$job_image;

$job->services=$matchingServices;
$success=insertJob($conn,$job);
$conn=NULL; //close the connection

if($success)
{
	
$to = $resident_email;
$subject = "Job Received, ID: ".$job->job_id;
$message = "Submit your reference number in the 'Existing options' section to receive updates.";
$headers = "From: Kirklees Council - NO REPLY <u1456282@unimail.hud.ac.uk>" . "\r\n";

mail($to,$subject,$message,$headers);

	include("views/add-job-confirm-view.php");
}else
{
	$errorMsgs[]="Problem inserting data into the database";
	include("views/add-job-error-view.php");
}
?>
