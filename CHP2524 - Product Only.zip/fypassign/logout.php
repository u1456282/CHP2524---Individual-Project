<!DOCTYPE HTML>
<html>
   <head><meta http-equiv="content-type" content="text/html;charset=utf-8" />
   <link rel="stylesheet" type="text/css" href="style.css">
    <body>
	<div class="divheader">
</div>
	<div class="divsection">
	<p class="HeaderLines"><span>Kirklees Council</span></p>
   <br>

	<section>

<?php
session_start();
session_destroy();
echo "User logged out";
header( "refresh:1;url=login.php" );
//header("Location: https://selene.hud.ac.uk/u1456282/fypassign/existingjob.php");
?>
</section>

