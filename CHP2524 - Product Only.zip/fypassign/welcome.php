<?php
session_start();
if(!isset($_SESSION["user"]))
{
	//user tried to access the page without logging in
	header( "Location: login.php" );
};

?>
<?php
include ("header.php");
include ("helpers/db_fncs.php");
include ("models/job-model.php");
?>
<?php
echo "<p>Successfully logged in as <b>".$_SESSION["user"].
header( "refresh:2;url=all-jobs.php" );

?>