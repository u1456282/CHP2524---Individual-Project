<?php
session_start();
?>
<?php
include ("header.php");
?>
<!DOCTYPE html>

<html>
<head>
    <title>Login</title>
</head>

<body>


    
<form action="login_process.php" method="post">
                <div class="FadeIn1">
		<div class="Details1">
            <fieldset>
            <legend align="center">Login</legend>
            <div class="ShowOnlyOnXL">
            <label for="username">Username:</label>
            </div>
    <input placeholder="Username" type="text" id="username" name="username" >
	<br>
    <div class="ShowOnlyOnXL">
	<label for="password" >Password:</label>
    </div>
    <input placeholder="Password" type="password" id="password" name="password">
	<br>
    <input type="submit" name="login" value="Login" class="LogInButton">
    <input class="ResetButton" type="reset" name="Reset">
	    </fieldset>
            </div>
</form>

</body>
</html>
