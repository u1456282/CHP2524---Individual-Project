

<?php

// Connect
$job_id = $_GET['job_id'];
$job_progress = $_GET['job_progress'];
$job_yard = $_GET['job_yard'];


if(isset($_POST['update']))
{
   $hostname = "localhost";
   $username = "u1456282";
   $password = "30oct95";
   $databaseName = "u1456282";
   
   $connect = mysqli_connect($hostname, $username, $password, $databaseName);
   
   // get values form input numbers
   
   $job_id = $_POST['job_id'];
   $job_progress = $_POST['job_progress'];
           
   // mysql query to Update data
   $query = "UPDATE `job` SET `job_progress`= $job_progress WHERE `job_id` = $job_id";
   header( "refresh:0;" );
   
   $result = mysqli_query($connect, $query);
   
   
   if($result)
   {
      
       		//include("views/update-confirm-view.php");
   }else{
       echo 'Job progress NOT updated';
   }
   mysqli_close($connect);
   
}

elseif(isset($_POST['yardupdate']))
{
   $hostname = "localhost";
   $username = "u1456282";
   $password = "30oct95";
   $databaseName = "u1456282";
   
   $connect = mysqli_connect($hostname, $username, $password, $databaseName);
   
   // get values form input numbers
   
   $job_id = $_POST['job_id'];
   $job_yard = $_POST['job_yard'];
           
   // mysql query to Update data
   $query = "UPDATE `job` SET `job_yard`= $job_yard WHERE `job_id` = $job_id";
   header( "refresh:0;" );
   
   $result = mysqli_query($connect, $query);
   
   
   if($result)
   {
      
       		//include("views/update-confirm-view.php");
   }else{
       echo 'Job progress NOT updated';
   }
   mysqli_close($connect);
   
}

?>

<!DOCTYPE html>

<html>



    <body>

        <form method="post">


<div class="DetailsNew">
	<div class="ShowOnlyOnXL">
<label for="title">ID Being Updated:</label>

<input type="text" name="job_id" value="<?php echo htmlentities($job_id); ?>" class="UpdateTextBox"><br>
	



<label for="title">Job Progress:</label>

            <input id="toupdate" type="number" name="job_progress" value="<?php echo htmlentities($job_progress); ?>"class="UpdateTextBox" id="toupdate" > <br>
</div>
<div class="range">
  <input type="range" min="1" max="4" steps="1" value="1" id="slider"> 
  
  
  <ul class="ul-range-labels">
  <li class="range-labels">1</li>
  <li class="range-labels">2</li>
  <li class="range-labels">3</li>
  <li class="range-labels">4</li>

</ul>
  
</div>


<script>
var slider = document.getElementById("slider");
var toupdate = document.getElementById("toupdate");

slider.onchange = function(){
    toupdate.value = slider.value;
};
</script>

<br>
				<label for="title">Designated Yard:</label>
            
            <div class="dropdown">
            <select name="job_yard">
  <option class="DDC" value="0">Please select one</option>             
  <option class="DDC" value="1">NONE ASSIGNED</option>
  <option class="DDC" value="2">Batley</option>
  <option class="DDC" value="3">Colne Valley</option>
  <option class="DDC" value="4">Denby Dale</option>
  <option class="DDC" value="5">Holme Valley</option>
  <option class="DDC" value="6">Huddersfield East</option>
  <option class="DDC" value="7">Huddersfield West</option>
  <option class="DDC" value="8">Kirkbutron</option>
  <option class="DDC" value="9">Mirfield</option>
  <option class="DDC" value="10">Spen Valley & Heckmondwike</option>
</select>
            </div>
            <br>
            <div class="HideOnXL">
              <div class="ShowIDOnMobile">
				<label for="title">Changes Job ID: <?php echo htmlentities($job_id); ?></label>
				<br>
        </div></div>
				<div class="DetailsNew">
             <input type="submit" name="update" value="Update Progress" class="ConsoleButton">
             <input type="submit" name="yardupdate" value="Update Yard" class="Console1Button">
            <br>
        </div>

</div>
        </form>

    </body>


</html>