<?php
function getServicesByJobId($conn,$job_id)
{
	$query = "SELECT * FROM service INNER JOIN job_service 
	ON service.service_id=job_service.service_id 
	WHERE job_service.job_id=:job_id";
	$stmt = $conn->prepare($query);
	$stmt->bindValue(':job_id',$job_id);
	$stmt->execute();
	$stmt->setFetchMode(PDO::FETCH_CLASS,'service');
	$matchingServices=[];
	while($service=$stmt->fetch())
	{
		$matchingServices[]=$service;
	}
	return $matchingServices;
}
function getAllServices($conn)
{
	$query = "SELECT * FROM service";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$stmt->setFetchMode(PDO::FETCH_CLASS,'service');
	$allServices=[];
	while($service=$stmt->fetch())
	{
		$allServices[]=$service;
	}
	return $allServices;
}
function getServiceById($conn,$service_id)
{
	$query = "SELECT * FROM service WHERE service_id=:service_id";
	$stmt = $conn->prepare($query);
	$stmt->bindValue(':service_id',$service_id);
	$stmt->execute();
	$stmt->setFetchMode(PDO::FETCH_CLASS,'service');
	$service=$stmt->fetch();
	return $service;
}
?>