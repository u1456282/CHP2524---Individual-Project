<?php

class Job{
	public $job_id;
	public $resident_name;
	public $job_notes;
	public $job_progress;
	public $job_datetime;
	public $services=[];
	public $job_image;
	public $job_yard;
	public $job_lat;
	public $job_lon;
	public $resident_email;
}

?>