<?php

class Service{
	public $service_id;
	public $service_name;
}
?>