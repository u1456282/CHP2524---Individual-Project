<?php
function getAllJobs($conn)
{
	$query = "SELECT * FROM job";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$allJob=[];
	$stmt->setFetchMode(PDO::FETCH_CLASS, 'job');
	while($dbJob=$stmt->fetch())
	{
		$allJob[]=buildJobObject($conn,$dbJob);
	}
	return $allJob;
}

function getJobById($conn,$job_id)
{
	$query = "SELECT * FROM job WHERE job_id=:job_id";
	$stmt = $conn->prepare($query);
	$stmt->bindValue(':job_id',$job_id);
	$stmt->setFetchMode(PDO::FETCH_CLASS,'job');
	$stmt->execute();
	$job=$stmt->fetch();
	$job=buildJobObject($conn,$job);
	return $job;
}
function insertJob($conn,$job)
{
	$query="INSERT INTO job VALUES (NULL, :resident_name, :job_notes, :job_progress, :job_datetime, :job_image, :job_yard, :job_lat, :job_lon, :resident_email)";
	$stmt=$conn->prepare($query);
	$stmt->bindValue(':resident_name', $job->resident_name);
	$stmt->bindValue(':job_notes', $job->job_notes);
	$stmt->bindValue(':job_progress', $job->job_progress);
	$stmt->bindValue(':job_datetime', $job->job_datetime);
	$stmt->bindValue(':job_image', $job->job_image);
	$stmt->bindValue(':job_yard', $job->job_yard);
	$stmt->bindValue(':job_lat', $job->job_lat);
	$stmt->bindValue(':job_lon', $job->job_lon);
	$stmt->bindValue(':resident_email', $job->resident_email);
	$affected_rows = $stmt->execute();
	$job->job_id=$conn->lastInsertId();
	foreach($job->services as $service)
	{
		$query="INSERT INTO job_service VALUES (:job_id, :service_id)";
		$stmt=$conn->prepare($query);
		$stmt->bindValue(':job_id', $job->job_id);
		$stmt->bindValue(':service_id', $service->service_id);
		$affected_rows = $stmt->execute();
	}
	if($affected_rows==1)
	{
		return true;
	}else{
		return false;
	}
}
function buildJobObject($conn,$job)
{
	$job->services=getServicesByJobId($conn,$job->job_id);
	return $job;
}

function deleteJob($conn,$job_id)
{
	$query = "DELETE FROM job WHERE job_id=:job_id";
	$stmt = $conn->prepare($query);
	$stmt->bindValue(':job_id',$job_id);
	$affected_rows=$stmt->execute();
	if($affected_rows==1)
	{
		return true;
	}else{
		return false;
	}
}
?>