//$(document).ready(function(){
//    $(".burger-nav").on("click", function(){
//        $("header nav ul").toggleClass("open");
//    });
//});
//
//function toggleSidebar(){
//    document.getElementById("sidebar").classList.toggle('active');
//}



$('.menu-toggle').click(function() {
  
  $('.TopNav').toggleClass('TopNav--open');
  $(this).toggleClass('open');
  
    $('.menudimmer').toggleClass('menudimmer--active');
  $(this).toggleClass('active');
  
});

