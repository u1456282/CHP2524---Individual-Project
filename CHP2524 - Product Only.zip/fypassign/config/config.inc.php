<?php
define( "DB_DATA_SOURCE", "mysql:host=localhost;dbname=u1456282" );
define( "DB_USERNAME", "u1456282" );
define( "DB_PASSWORD", "30oct95" );
try{
       $conn = new PDO('mysql:host=localhost;dbname=u1456282', 'u1456282', '30oct95');
}
catch (PDOException $exception) 
{
	echo "Error occured" . $exception->getMessage();
}
?>